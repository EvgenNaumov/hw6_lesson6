package ServerLog;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ServerLog {
    private static Logger logger;

    public static void writeLog(Class<?> inClass, String textLog){
        logger   =  LogManager.getLogger(inClass);
        logger.trace(textLog);
    }
}

package client;

public class ClientApp {
    public static void main(String[] args) {
        new MyClient().setVisible(true);
    }
}

package ListJob;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;

public class ListClientsThreads {


    private Map<String, String> listThreads;

    private static Map<String,String> listClientsThreads;

        public ListClientsThreads() {
            listClientsThreads = new HashMap<>();
        }

        public void setListThreads(String nick) {
            String jobId = UUID.randomUUID().toString();
            listClientsThreads.put(nick,jobId);
        }

    public void closeJob(String nick) {
            if (listClientsThreads.isEmpty()){
                return;
            }
        listClientsThreads.remove(nick);

    }

}
